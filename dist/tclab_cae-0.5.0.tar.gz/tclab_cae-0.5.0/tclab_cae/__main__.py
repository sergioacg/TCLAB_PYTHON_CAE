from .tclab_cae import diagnose


diagnose()